<?php
error_reporting(E_ALL ^ E_NOTICE);
?>
<footer class="bg-dark text-white text-center py-3 mt-auto">
    <div class="container">
        &copy; <?php echo date("Y"); ?> Betina Driggers. All rights reserved.
    </div>
</footer>